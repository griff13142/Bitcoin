package bitcoin;
import javax.swing.*;

public class Buying {
    private float Amount;
    //Function to determain how much Bitcoin you could buy at its current price
    public float Buy() {
        boolean checker = true;
       while(checker) {
           BTC Test3 = new BTC();
           float BuyingBTC = 0;
           float G;
          try {
                BuyingBTC = Float.parseFloat(JOptionPane.showInputDialog(null, "Please Enter Amount You Wish to Spend to Buy", "BTC Buying", 2));
               checker = false;
               float fAmount = BuyingBTC ;
           G= fAmount/ (Test3.HowMuch());
           Amount = G;
           JOptionPane.showMessageDialog(null,"Number of Coin  "+ G, "BTC Purchase Amount", 1);
           } catch (NumberFormatException e) {
               JOptionPane.showMessageDialog(null, "Please enter a correct dollar amount 0.00", "Error Occurred", 1);
           }
       }
        return Amount;
    }
}