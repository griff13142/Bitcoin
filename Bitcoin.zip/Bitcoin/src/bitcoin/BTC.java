/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bitcoin;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.io.IOException;
public class BTC {
    private String name;
    private String Amount;
    private float Pivot;
    private float BuyingAmount;
//Function to Webscrap for Current price of Bitcoin
    public String getCoin() {
        //Website
        String url = "https://coinmarketcap.com/";
        try {
            //Grabs the HTML code fromt Web page and narrows down what to find
            final Document doc = Jsoup.connect(url).get();
            Elements body = doc.select("table.cmc-table.cmc-table___11lFC.cmc-table-homepage___2_guh");
            int control = 0;
            for (Element e : body.select("tr ")) {
                String Title = e.select("td div.sc-16r8icm-0.dnwuAU a.cmc-link div.sc-16r8icm-0.sc-1teo54s-0.gKtDwz div.sc-16r8icm-0.sc-1teo54s-1.lgwUsc p.sc-1eb5slv-0.iJjGCS").text();
                name = Title;
                String face = e.select("td div.price___3rj7O a.cmc-link").text();
                Amount = face;
                //if loop to scrape only needed information
                if (control == 1) {
                    break;
                }
                control += 1;
            }
        } catch (IOException e) {
        }
        return name + Amount;
    }
    //Function to get the Pivot Point for Resistance/Support Calculations
    public float getPivot() {
        String url1 = "https://www.investing.com/crypto/bitcoin/historical-data";
        try {
            Document doc2 = Jsoup.connect(url1).get();
            //Elements body2 = doc2.select("table.genTbl.closedTbl.historicalTbl");
            //For Loop to grab specific infromation from webpage
            for (int j = 0; j < doc2.select("tr").size(); j++) {
                if (j == 2) {
                    String close = doc2.select("tr td").get(8).text();
                    String open = doc2.select("tr td").get(9).text();
                    String high = doc2.select("tr td").get(10).text();
                    String low = doc2.select("tr td").get(11).text();
                    close =close.replace(",","");
                    open =open.replace(",","");
                    high =high.replace(",","");
                    low =low.replace(",","");
                    float closef = Float.parseFloat(close);
                    float openf = Float.parseFloat(open);
                    float highf = Float.parseFloat(high);
                    float lowf = Float.parseFloat(low);
                    Pivot = (highf+lowf+closef)/3;
                } else {
                    continue;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return Pivot;
    }
    //Function to help calculate how much Bitcoin you can buy with User entered amount
    public float HowMuch(){
        String url3 = "https://www.investing.com/crypto/bitcoin/historical-data";
        try {
            Document doc3 = Jsoup.connect(url3).get();
            //Elements body3 = doc3.select("table.genTbl.closedTbl.historicalTbl");
            //int control = 0; //interaction variable
            for (int j = 0; j < doc3.select("tr").size(); j++) {
                if (j == 2) {
                    String close = doc3.select("tr td").get(2).text();
                    close = close.replace(",", "");
                    float closef = Float.parseFloat(close);
                    BuyingAmount =closef;

                }
            }
        }
         catch (IOException e) {
        }
        return BuyingAmount;
    }
    }