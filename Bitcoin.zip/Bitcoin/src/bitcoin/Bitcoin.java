package bitcoin;
import javax.swing.JOptionPane;

public class Bitcoin {
//Recusion Function. Will run though whole menu if selected in the Menu option
   static int All(int n){
        if (n <= 3){
            switch(n) {
                case 1:
                    BTC Test1 = new BTC();
                    String K = Test1.getCoin();
                    JOptionPane.showMessageDialog(null, K, "BTC Current Amount ", 1);
                    break;
                case 2:
                    Buying Test2 = new Buying();
                    Test2.Buy();
                    break;
                case 3:
                    Resistance Test3 = new Resistance();
                    Test3.Resistance();
                    break;
                default: break;
            }
            return All(n+1);
        }
        else{
            return 4;
        }
    }
    public static void main(String[] args) {
        //Calling other class
        BTC Test1 = new BTC();
        String K = Test1.getCoin();
        boolean Starter = false;
        //Start of Menu
        while(!Starter) {
            try {
                int choice1 = Integer.parseInt(JOptionPane.showInputDialog(null, "Please Enter the Number Corresponding to the Action Desired " +
                        "\n0) Run Everything" +
                        "\n1) See Current Price of Bitcoin" +
                        "\n2) Find Out How Much Bitcoin You Could Buy" +
                        "\n3) See Current Resistance and Support Levels" +
                        "\n4) Quit", "Menu", 1));
                //Menu Choices
                switch(choice1){
                    case 0:
                          All(choice1);
                        break;

                    case 1:
                        JOptionPane.showMessageDialog(null, K, "BTC Current Amount ", 1);
                        break;
                    case 2:
                        Buying Test2 = new Buying();
                        Test2.Buy();
                        break;
                    case 3:
                        Resistance Test3 = new Resistance();
                        Test3.Resistance();
                        break;
                    case 4:
                        Starter = true;
                        JOptionPane.showMessageDialog(null, "Have a Good Day! ", "Good Bye! ", 1);
                        break;
                    default:
                        if (choice1 < 0 || choice1 >4 ){
                            JOptionPane.showMessageDialog(null,"Invalid Entry Please Try Again ", "Invalid Entry ", 1);
                        }
                        else {
                            JOptionPane.showMessageDialog(null, "Have a Good Day! ", "Good Bye! ", 1);
                        }
                }
                //Catch for invalid Menu Selection
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null,"Invalid Entry Please Try Again ", "Invalid Entry ", 1);
            }
        }
    }

}
