/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bitcoin;

import org.jsoup.Jsoup;
import org.jsoup.select.Elements;
import javax.swing.*;
import java.io.IOException;

import org.jsoup.nodes.Document;
public class Resistance {
   private float R1;
   private float R2;
   private float R3;
   private float S1;
   private float S2;
    private float PP;
//Function to Calculate Resisitance points and Supports for Bitcoin using histoirc data
    public float  Resistance(){
        String url1 = "https://www.investing.com/crypto/bitcoin/historical-data";
        try {
            Document doc2 = Jsoup.connect(url1).get();
            //Elements body2 = doc2.select("table.genTbl.closedTbl.historicalTbl");
           for (int j = 0; j < doc2.select("tr").size(); j++) {
                if (j == 2) {
                    String close = doc2.select("tr td").get(8).text();
                    String open = doc2.select("tr td").get(9).text();
                    String high = doc2.select("tr td").get(10).text();
                    String low = doc2.select("tr td").get(11).text();
                    close =close.replace(",","");
                    open =open.replace(",","");
                    high =high.replace(",","");
                    low =low.replace(",","");
                    float closef = Float.parseFloat(close);
                    float openf = Float.parseFloat(open);
                    float highf = Float.parseFloat(high);
                    float lowf = Float.parseFloat(low);
                     PP = (highf+lowf+closef)/3;
                     R1= (PP*2)-lowf;
                     R2= PP +(highf-lowf);
                     R3= highf +((PP-lowf)*2);
                     S1 = (PP*2)-highf;
                     S2 = PP -(highf-lowf);
                } else {
                    continue;
                }
                JOptionPane.showMessageDialog(null,"First Resistance $"+ R1 + "\nSecond Resistance $"+ R2 + "\nThird Resistance $"+ R3 + "\nFirst Support $"+S1+"\nSecond Support $"+ S2, "Resistance/Support Points", 1);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return PP;
    }
}

